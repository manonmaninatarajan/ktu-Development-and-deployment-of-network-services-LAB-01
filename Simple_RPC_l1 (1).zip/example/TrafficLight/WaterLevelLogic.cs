namespace Servers;

using NLog;

using Services;

/// <summary>
/// water container state descritor.
/// </summary>
public class Waterlevelstate
{
   
	/// <summary>
	/// Access lock.
	/// </summary>
	public readonly object AccessLock = new object();

	/// <summary>
	/// Last unique ID value generated.
	/// </summary>
	public int LastUniqueId;

    /// <summary>
    /// Water level state
    /// </summary>
    public Waterleverstate waterleverstate;
    /// <summary>
    /// upper limit
    /// </summary>
    public int upperlimit;
    /// <summary>
    /// lower limit
    /// </summary>
    public int lowerlimit;
    /// <summary>
    /// current level of water
    /// </summary>
    public int currentlever;
	
}


/// <summary>
/// <para>Water level logic.</para>
/// <para>Thread safe.</para>
/// </summary>
class WaterLevelLogic
{
	/// <summary>
	/// Logger for this class.
	/// </summary>
	private Logger mLog = LogManager.GetCurrentClassLogger();

	/// <summary>
	/// Background task thread.
	/// </summary>
	private Thread mBgTaskThread;

	/// <summary>
	/// State descriptor.
	/// </summary>
	private Waterlevelstate mState = new Waterlevelstate();
	

	/// <summary>
	/// Constructor.
	/// </summary>
	public WaterLevelLogic()
	{
		//initial value of the waterlever
		mState.upperlimit = 75;//Initial upper limit
		mState.lowerlimit = 25;//Initial lower limit
		mState.currentlever = 45;//Initial water level limit
		//start the background task for changing upper and lower limit
		mBgTaskThread = new Thread(BackgroundTask);//creating Background thread
		mBgTaskThread.Start();
	}

	/// <summary>
	/// Get next unique ID from the server. Is used by cars to acquire client ID's.
	/// </summary>
	/// <returns>Unique ID.</returns>
	public int GetUniqueId() 
	{
		lock( mState.AccessLock )
		{
			mState.LastUniqueId += 1;
			return mState.LastUniqueId;
		}
	}


    /// <summary>
    /// Get the current water level state of the upper and lower limit in the container.
    /// </summary>
    /// <returns>Current water level.</returns>
    public Waterleverstate GetWaterleverstate()
	{
		lock (mState.AccessLock)
		{
			return mState.waterleverstate;
		}
	}

    /// <summary>
    /// Get the current upper limit of the water container.
    /// </summary>
    /// <returns>upper limit of the water level.</returns>
    public int upperlimit()
	{
		lock (mState.AccessLock)
		{
			return mState.upperlimit;
		}
	}
    Random rnd = new Random();
    /// <summary>
    /// Get the current Lower limit of the water container.
    /// </summary>
    /// <returns>Lower limit of the water level.</returns>
    public int lowerlimit()
    {
        lock (mState.AccessLock)
        {
            return mState.lowerlimit;
        }
    }
    /// <summary>
    /// Get the current limit of the water container.
    /// </summary>
    /// <returns>limit of the water level.</returns>
    public int currentlimit()
	{
        lock (mState.AccessLock)
        {
            return mState.currentlever;
        }

    }

    /// <summary>
    /// Add water to the container if below the lower limit.
    /// </summary>
    /// <returns>Result of the water addition attempt.</returns>
    public waterLevelchecker addwater(AddDesc addDesc)
    {

        var par = new waterLevelchecker();
        lock (mState.AccessLock)
        {
            
            if (mState.currentlever < mState.lowerlimit)//checks if current level is lower than the lowerlimit limit
            {
                mState.currentlever += addDesc.AdderNumber;//if true random units of water is Added
                par.IsSuccess = true;
                if (addDesc.AdderNumber != 0)
                {
                    mLog.Info($"{addDesc.AdderNumber} units of water is added and Current level of water is Updated to: {mState.currentlever}  units , upper limit: {mState.upperlimit},lower limit: {mState.lowerlimit}");

                }
                
            }
            else
            {
                mLog.Info($"water container is denied to Add water");
                par.IsSuccess = false;
                par.failurereason = "Current level of water is below or equal to the lower limit";

            }
            return par;

        }
    }

    /// <summary>
    /// Remove water from the container if above the upper limit.
    /// </summary>
    /// <returns>Result of the water removal attempt.</returns>

    public waterLevelchecker removewater(RemoveDesc removedesc)
    {
        var par = new waterLevelchecker();
        lock (mState.AccessLock)
        {
           
            if (mState.currentlever > mState.upperlimit )//checks if current level is higher than the upper limit
            {
                mState.currentlever -= removedesc.RemoverNumber;//if true random units of water is removed
                par.IsSuccess = true;
                if (removedesc.RemoverNumber != 0)
                {
                    mLog.Info($"{removedesc.RemoverNumber} units of water removed Current level of water is Updated to: {mState.currentlever}  units , upper limit: {mState.upperlimit},lower limit: {mState.lowerlimit}");
                }

            }
            else if(mState.currentlever <= mState.upperlimit)
            {
                mLog.Info($"water container is denied to Remove water");
                par.IsSuccess = false;
                par.failurereason = "Current level of water is above the upper limit";
               
            }
            return par;
           
        }
    }





    /// <summary>
    /// Background task for the water container.
    /// </summary>
    public void BackgroundTask()
	{
		//intialize random number generator
		var rnd = new Random();
		while( true )
		{
            //sleep for 8 second while
            Thread.Sleep(8000); 
			lock( mState.AccessLock )
			{
				int lowlimit = rnd.Next(1,100);//criteria for generating random number for lower limit
                int uplimit = rnd.Next(lowlimit+1,lowlimit+ 100);//criteria for generating random number for upper
                                                                 //limit ensuring upper limit is always greater than the lower limit
				int curlimit = mState.currentlever;

				mState.lowerlimit = lowlimit;
				mState.upperlimit = uplimit;
				

                mLog.Info($"Updated limits for every 8 seconds: Lower = {mState.lowerlimit}, Upper = {mState.upperlimit}, current level : {curlimit}");
            }
		}
	}
}