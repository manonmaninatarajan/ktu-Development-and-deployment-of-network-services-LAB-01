namespace Servers;

using Services;

/// <summary>
/// Service
/// </summary>
public class WaterLevelService : IWaterLevelService
{
	//NOTE: instance-per-request service would need logic to be static or injected from a singleton instance
	private readonly WaterLevelLogic mLogic = new WaterLevelLogic();


	/// <summary>
	/// Get next unique ID from the server. Is used by cars to acquire client ID's.
	/// </summary>
	/// <returns>Unique ID.</returns>
	public int getUID() 
	{
		return mLogic.GetUniqueId();
	}

    /// <summary>
    /// Get GetWaterleverstate.
    /// </summary>
    /// <returns>water level state.</returns>				
    public Waterleverstate GetWaterleverstate()
	{
		return mLogic.GetWaterleverstate();

    }

    /// <summary>
    /// Get the current upper limit of the water level.
    /// </summary>
    /// <returns>Current upper limit.</returns>
    public int getupperlimit()
	{
		return mLogic.upperlimit();
      
	}
    /// <summary>
    /// Add water to the container. Will only succeed if the water level is below the lower limit.
    /// </summary>
    /// <returns>Result of the water addition attempt.</returns>
    public waterLevelchecker addwater(AddDesc adddesc)
	{
		return mLogic.addwater(adddesc);

	}
    /// <summary>
    /// Remove water from the container. Will only succeed if the water level is above the upper limit.
    /// </summary>
    /// <returns>Result of the water removal attempt.</returns>
    public waterLevelchecker removewater(RemoveDesc removeDesc)
	{
		return mLogic.removewater(removeDesc);

    }
    /// <summary>
    /// Get the current lower limit of the water level.
    /// </summary>
    /// <returns>Current lower limit.</returns>		
    public int getlowerlimit()
	{
		return mLogic.lowerlimit();
	}
    /// <summary>
    /// Get current GetWaterleverstate.
    /// </summary>
    /// <returns>current water level state.</returns>			
    public int getcurrentlever()
	{
		
        return mLogic.currentlimit();

    }
}